const FollowApi= require('./follow_api_util.js');

function FollowToggle(el) {
    const $el = $(el);
    // debugger
    this.userId = $el.data().userId;
    this.followState = $el.data().initialFollowState;
    this.render($el);
    this.handleClick();
}

    FollowToggle.prototype.render = function($el) {
        // console.log(this)
        if (this.followState === 'unfollowed') {

            $el.html('Follow!') ;
        } else {
            $el.html('Unfollow!');
        }
    };

    FollowToggle.prototype.toggle = function(){
        this.followState === 'unfollowed' ? this.followState = 'followed' : this.followState = 'unfollowed';
    }

    FollowToggle.prototype.handleClick = function() {
        // const userInfo = {

        //     userId: this.userId,
        //     followState: this.render(),

        // };
        $('.follow-toggle').on('click', e => {
            e.preventDefault();
            // debugger;
            this.followState === "unfollowed" ? FollowApi.followUser(this.userId).then(()=> this.toggle())
            : FollowApi.unfollowUser(this.userId).then(() =>
                this.toggle()
            );
               
        });
    };


   

    


module.exports = FollowToggle;