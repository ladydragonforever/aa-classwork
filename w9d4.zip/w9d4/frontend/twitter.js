import FollowToggle from "./follow_toggle.js";

// debugger
$(() => {
    $(".follow-toggle").each((idx,el)=> {
        new FollowToggle(el);
    });
});
