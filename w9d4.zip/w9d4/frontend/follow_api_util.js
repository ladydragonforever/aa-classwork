const FollowApi = {
    followUser: function(userId) {
        return $.ajax({
            method: 'Post',
            url: `/users/${userId}/follow`,
            dataType: 'json'
        });
    },

    unfollowUser: function(userId) {
        return $.ajax({
            method: 'Delete',
            url: `/users/${userId}/follow`,
            dataType: 'json'
        });
    }
};

module.exports = FollowApi;