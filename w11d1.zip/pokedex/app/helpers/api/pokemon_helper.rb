module Api::PokemonHelper
end
