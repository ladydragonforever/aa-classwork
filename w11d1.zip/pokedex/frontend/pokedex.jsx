import React from "react";
import ReactDOM from "react-dom";
import * as ApiUtil from "./util/api_util";
import { RECEIVE_ALL_POKEMON, receiveAllPokemon} from "./actions/pokemon_actions";
import configureStore from "./store/store";

document.addEventListener("DOMContentLoaded", ()=>{
  const root = document.getElementById("root");
  ReactDOM.render(<h1>React is working</h1>, root);
})