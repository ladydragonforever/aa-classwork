export const fetchALlPokemon = () => {
  return $.ajax({
    method: "get",
    url: "/api/pokemon"

  });
};

window.fetchALlPokemon = fetchALlPokemon;