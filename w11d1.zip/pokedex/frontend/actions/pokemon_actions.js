export const RECEIVE_ALL_POKEMON = "RECEIVE_ALL_POKEMON";

export const receiveALLPokemon = (pokemon) => ({
  type: RECEIVE_ALL_POKEMON,
  pokemon 
});

window.receiveALLPokemon = receiveALLPokemon;