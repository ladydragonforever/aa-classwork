export const RECEIVE_TODOS = "RECEIVE_TODOS";
export const RECEIVE_TODO = "RECEIVE_TODO";

// todos will be passed in as an array
// i.e. [wash dog, wash car, wash self]
export const receiveToDos = todos => (
  {
    type: "RECEIVE_TODOS",
    todos: todos
  }
);

// i.e. {wash dog}
export const receiveToDo = todo => (
  {
    type: "RECEIVE_TODO",
    todo: todo
  }
);

