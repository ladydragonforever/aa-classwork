
export const fetchTodos = ()=>{

  return (
    $.ajax({
      method: 'get',
      url: ' /api/todos'
    }).then(
      res => console.log(res)
    ).catch(
      error => console.log(error)
    )
  ); 

};
