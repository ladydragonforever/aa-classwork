import React from "react";
import ReactDOM from "react-dom";
import RootReducer from "./reducers/root_reducer";
import configureStore from "./store/store";
import { receiveToDo, receiveToDos } from "./actions/todo_actions";
import Root from "./components/root";
import {allToDos} from "./reducers/selectors";



document.addEventListener("DOMContentLoaded", ()=> {
  const store = configureStore();
  window.store = store;
  window.receiveToDo = receiveToDo;
  window.receiveToDos = receiveToDos;
  window.allToDos = allToDos;
  const root = document.getElementById("content");
  ReactDOM.render(<Root store={store}/>, root );
}
)

// const newTodos = [{
//   id: 1,
//   title: "dirty car",
//   body: "with soap",
//   done: false
// }, {
//   id: 2,
//   title: "dirty dog",
//   body: "with shampoo",
//   done: true
// }]