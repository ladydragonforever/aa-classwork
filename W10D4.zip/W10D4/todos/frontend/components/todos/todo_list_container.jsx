import { connect } from 'react-redux';

import ToDolist from "./todo_list";
import { receiveToDo } from "../../actions/todo_actions";
import { allToDos } from "../../reducers/selectors";

const mapStateToProps = state => ({
  todos: allToDos(state)
});

const mapDispatchToProps = dispatch => ({
  receiveToDo: todo => dispatch(receiveToDo(todo))

});

export default connect(mapStateToProps, mapDispatchToProps)(ToDolist);