import React from 'react';

const ToDoListItem = ({title}) => {
  return (
      <li>
        {title}
      </li>
  );
};

export default ToDoListItem;