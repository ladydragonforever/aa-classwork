import React from "react";
import {uniqueId} from "./util";

// id: 1,
// title: "wash car",
// body: "with soap",
// done: false

class ToDoForm extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      id: uniqueId(),
      title: '',
      body: '',
      done: false
    };
    this.updateTitle = this.updateTitle.bind(this);
    this.updateBody = this.updateBody.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  updateTitle(e) {
    this.setState({ title: e.target.value});
  }

  updateBody(e) {
    this.setState({ body: e.target.value});
  }

  handleSubmit(e) {
    e.preventDefault(); 
    this.props.receiveToDo(this.state);
    this.setState({
      id: uniqueId(),
      title: '',
      body: '',
      done: false
    }); 
  }


  render() {
    return (
      <div>
        <form action="">
          <label> Title
            <input type="text" onChange={this.updateTitle}/>
          </label>

          <label> Body
            <input type="text" onChange={this.updateBody}/>
          </label>

          <input type="submit" value="Create Todo!" onClick={this.handleSubmit}/> 

        </form>
      </div>
    )
  }
}


export default ToDoForm;

