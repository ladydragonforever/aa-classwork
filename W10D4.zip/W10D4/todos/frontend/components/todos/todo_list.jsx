import React from "react";
import ToDoListItem from "./todo_list_item";
import ToDoForm from "./todo_form";

const ToDoList = ({ todos, receiveToDo}) => {
        //  debugger;
        return(
               <div>
                     <ul>
                            {
                            todos.map((todo) => 
                                          <ToDoListItem 
                                          title={todo.title} 
                                          key={todo.id}/>
                                   )
                            }   


                     </ul> 

                      <ToDoForm receiveToDo={receiveToDo}/>
               </div>

        );
 };
        


export default ToDoList;