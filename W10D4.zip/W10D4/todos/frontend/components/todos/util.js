export const uniqueId = () => {
  return (new Date().getTime());
};

