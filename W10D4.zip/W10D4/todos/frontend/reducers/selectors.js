export const allToDos = (state) =>{
  // console.log(state);
  let todoArr = Object.keys(state.todos).map((el) => state.todos[el]);
  return todoArr;
};



