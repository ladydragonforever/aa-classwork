import React from 'react';


class Clock extends React.Component {
  
  constructor(props){
    super(props);
    this.state = {
      time: new Date()
    };
  
  }


  tick(){
    this.setState({time: new Date()});
  }

  
  componentDidMount(){
    this.handle = setInterval(() => {
      this.tick();
    }, 1000);

  }

  componentWillUnmount(){
    clearInterval(this.handle);
  }



  render(){
    return(

      <div>
        <h1>Clock </h1>
        <div className="clock">
          <div>
          <span id="time">Time:</span>
          </div>
          <div>
            <span id="itemTime">{this.state.time.getHours()}:</span>
            <span id="itemTime">{this.state.time.getMinutes()}:</span>
            <span id="itemTime">{this.state.time.getSeconds()}</span>
          </div>
          <div> 
            <span id="pdt">PDT</span>
          </div> 
        </div>

      </div>


    );
  }

} 


export default Clock;