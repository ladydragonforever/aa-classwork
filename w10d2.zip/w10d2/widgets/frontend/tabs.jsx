import React from "react";

class Tabs extends React.Component{

  constructor(props){
    super(props);
    this.state = {
      content: {One: "I'm the first!", Two: "I'm the second!", Three: "I'm the third!"},
      title: "",
    };
    this.handle = this.handle.bind(this);
  }  

  handle(event){ 
    // debugger
  this.setState({
    title: event.currentTarget.innerHTML,
    content: this.state.content[event.currentTarget.innerHTML]
  });
  
   
  }
  render(){
    return(
     
       <ul >
         <h1>
           <header onClick={this.handle}>One</header>
        </h1>
        <h1>
          <header onClick={this.handle}>Two</header>
        </h1>
        <h1> 
          <header onClick={this.handle}>Three</header>
        </h1>
       </ul>

    );
    
    }

}

export default Tabs;